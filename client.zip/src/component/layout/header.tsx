import * as React from "react";
import { Component } from "react";
import { NavLink } from "react-router-dom";

export class Header extends Component {
  render() {
    return (
      <div className="navbar navbar-expand-lg navbar-dark bg-dark">
        <NavLink className="navbar-brand" to="/" exact>
          Vacations
        </NavLink>
        <ul className="navbar-nav mr-auto mt-2 mt-lg-0">
          <li className="nav-item ">
            <NavLink className="nav-link" to="/" exact>
              Home
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/vacations" exact>
              Vacations
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink className="nav-link" to="/admin" exact>
              Admin
            </NavLink>
          </li>
        </ul>

        <NavLink className="nav-link" to="/login" exact>
          <button
            className="btn btn-outline-success my-2 my-sm-0"
            type="button"
          >
            Login
          </button>
        </NavLink>
      </div>
    );
  }
}
