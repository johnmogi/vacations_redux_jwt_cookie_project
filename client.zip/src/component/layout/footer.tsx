import * as React from 'react';
import { Component } from 'react';
interface footerState {
    currentYear: number;
}
export class Footer extends Component<any, footerState> {

    render() {
        return (
            <div className="footer text-center">
                <p>All rights reserved &copy; JohnMogi.com</p>
            </div>
        );
    }
}