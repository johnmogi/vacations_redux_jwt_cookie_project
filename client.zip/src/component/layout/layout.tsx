import * as React from 'react';
import { Component } from 'react';
import { BrowserRouter } from 'react-router-dom';
import { Header } from './header';
import { Main } from './main';
import { SideMenu } from './side-menu';
import { Footer } from './footer';

export class Layout extends Component {
    render() {
        return (
            <div className="layout container-fluid">
                <BrowserRouter>
                    <Header />
                    <main className="container row">
                        <aside className="col-2">
                            <SideMenu />
                        </aside>
                        <section className="col-10">
                            <Main />
                        </section>
                    </main>
                    <Footer />
                </BrowserRouter>
            </div>
        );
    }
}