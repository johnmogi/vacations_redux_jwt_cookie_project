import * as React from 'react';
import { Component } from 'react';

export class Main extends Component {
    render() {
        return (
            <div className="main">
                <h1>main</h1>
            </div>
        );
    }
}