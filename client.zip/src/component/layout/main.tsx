import * as React from "react";
import { Component } from "react";
import { Route, Switch, Redirect } from "react-router-dom";
import { Home } from "../pages/home";
import { Vacations } from "../pages/vacations";
import { Admin } from "../pages/auth/admin";
import { Login } from "../pages/auth/login";
import { NotFound } from "../pages/not-found";

export class Main extends Component {
  render() {
    return (
      <div className="main">
        <Switch>
          <Route path="/home" component={Home} exact />
          <Route path="/vacations" component={Vacations} exact />
          <Route path="/admin" component={Admin} exact />
          <Route path="/login" component={Login} exact />
          {/* <Route path="/logout" component={Logout} exact /> */}
          <Redirect from="/" to="/home" exact />
          <Route from="" to="/404" component={NotFound} />
        </Switch>
      </div>
    );
  }
}
