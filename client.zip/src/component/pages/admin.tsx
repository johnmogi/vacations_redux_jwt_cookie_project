import * as React from 'react';
import { Component } from 'react';

export class Admin extends Component {
    render() {
        return (
            <div className="admin">
                <h1>admin</h1>
            </div>
        );
    }
}