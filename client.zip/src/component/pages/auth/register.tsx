import * as React from "react";
import { Component } from "react";

export class Register extends Component {
  render() {
    return (
      <div className="register">
        <h1>register</h1>
      </div>
    );
  }
}
