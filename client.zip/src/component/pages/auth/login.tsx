import * as React from "react";
import { Component } from "react";

export class Login extends Component {
  render() {
    return (
      <div className="login">
        <h1>login</h1>
      </div>
    );
  }
}
