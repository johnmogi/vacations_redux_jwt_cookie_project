import * as React from 'react';
import { Component } from 'react';

export class Vacations extends Component {
    render() {
        return (
            <div className="vacations">
                <h1>vacations</h1>
            </div>
        );
    }
}