import * as React from "react";
import { Component } from "react";
import Iframe from "react-iframe";

export class NotFound extends Component {
  render() {
    return (
      <div className="notfound">
        <Iframe
          url="http://www.youtube.com/embed/xDMP3i36naA"
          position="absolute"
          width="100%"
          id="myId"
          className="myClassname"
          height="100%"
          styles={{ height: "25px" }}
        />
      </div>
    );
  }
}
